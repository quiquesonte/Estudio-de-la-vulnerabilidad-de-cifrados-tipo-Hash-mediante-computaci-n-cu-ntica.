import struct

# Funciones auxiliares
def rotacion_izq(x, c):
    """Realiza un desplazamiento circular a la izquierda de 'x' por 'c' bits."""
    return (x << c) | (x >> (32 - c))

def F(X, Y, Z):
    """Función de ronda para el paso 1."""
    return (X & Y) | (~X & Z)

def G(X, Y, Z):
    """Función de ronda para el paso 2."""
    return (X & Z) | (Y & ~Z)

def H(X, Y, Z):
    """Función de ronda para el paso 3."""
    return X ^ Y ^ Z

def I(X, Y, Z):
    """Función de ronda para el paso 4."""
    return Y ^ (X | ~Z)

"""Constante k."""
K = [
        0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
        0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
        0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
        0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
        0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
        0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
        0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
        0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
        0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
        0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
        0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
        0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
        0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
        0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
        0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
        0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391
    ]
"""Constante s."""
S = [
    7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,
    5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,
    4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,
    6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21
]
# Función principal MD5
def md5(mensaje):
    """Calcula el hash MD5 del mensaje dado."""
    
    # Inicialización de variables
    A = 0x67452301
    B = 0xEFCDAB89
    C = 0x98BADCFE
    D = 0x10325476

    # Pre-procesamiento del mensaje
    original_byte_len = len(mensaje)
    original_bit_len = original_byte_len * 8
    mensaje += b'\x80'  # Añade un bit '1' seguido de ceros
    while len(mensaje) % 64 != 56:
        mensaje += b'\x00'  # Rellena con ceros al mensaje hasta que su longitud en bits sea congruente con 448 módulo 512
        
    # Calculamos la longitud original del mensaje en bits y realizamos el módulo 2^64
    original_bit_length_mod_2_64 = original_bit_len % (2**64)

    # Convertimos el valor resultante a bytes en little-endian
    length_bytes = original_bit_length_mod_2_64.to_bytes(8, byteorder='little')

    # Añadimos la longitud al mensaje
    mensaje += length_bytes

    # Procesamiento del mensaje en bloques de 512 bits
    for i in range(0, len(mensaje), 64):
        chunk = mensaje[i:i+64]  # Divide el mensaje en bloques de 512 bits
        a, b, c, d = A, B, C, D  # Guarda los valores iniciales de los registros

        # Operaciones principales
        for j in range(64):
            if 0 <= j <= 15:
                f = F(b, c, d)
                g = j
            elif 16 <= j <= 31:
                f = G(b, c, d)
                g = (5 * j + 1) % 16
            elif 32 <= j <= 47:
                f = H(b, c, d)
                g = (3 * j + 5) % 16
            elif 48 <= j <= 63:
                f = I(b, c, d)
                g = (7 * j) % 16
            

            W = int.from_bytes(chunk[4*g:4*g+4], byteorder='little') # convertir un conjunto de cuatro bytes de chunk en un entero, interpretando los bytes en orden little-endian

            temp = (b + rotacion_izq((a + f + W + K[j]) & 0xFFFFFFFF, S[j])) 

            a, b, c, d = d, temp, b, c
            # print("Valores intermedios de los registros después de la ronda", j+1, ":", hex(a), hex(b), hex(c), hex(d))


        # Actualización de los valores de los registros
        A = (A + a) & 0xFFFFFFFF
        B = (B + b) & 0xFFFFFFFF
        C = (C + c) & 0xFFFFFFFF
        D = (D + d) & 0xFFFFFFFF

    # Convertir el resultado en una cadena hexadecimal
    digest = (A.to_bytes(4, byteorder='little') +
          B.to_bytes(4, byteorder='little') +
          C.to_bytes(4, byteorder='little') +
          D.to_bytes(4, byteorder='little'))
    
    return digest

# Comprobar con hashlib
import hashlib

mensaje = b"El algoritmo MD5."
hash_esperado = hashlib.md5(mensaje).hexdigest()
hash_resultante = md5(mensaje)

print("La frase a codificar: The quick brown fox jumps over the lazy dog.")
print("Hash MD5 esperado:", hash_esperado)

hash_resultante_legible = ''.join([f'{byte:02x}' for byte in hash_resultante])

print("Hash MD5 resultante:", hash_resultante_legible)

if hash_esperado == hash_resultante_legible:
    print("El hash MD5 es correcto.")
else:
    print("El hash MD5 es incorrecto.")