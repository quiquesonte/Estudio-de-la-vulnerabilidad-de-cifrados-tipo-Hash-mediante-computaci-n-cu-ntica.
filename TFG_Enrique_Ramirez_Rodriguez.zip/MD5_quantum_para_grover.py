from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister
from qiskit.quantum_info import Statevector
from qiskit.visualization import plot_histogram
from qiskit.circuit.library import DraperQFTAdder
from qiskit.circuit import ControlledGate
import qiskit.quantum_info as qi

# Número de registros de qbits
numero_bits = 4
# Inicialización del adder
adder = DraperQFTAdder(numero_bits, kind='half', name='DraperQFTAdder')

# Convertimos el valor hexadecimal en binario
hex_value_A = 0x67452301 & 0xF  
hex_value_B = 0xEFCDAB89 & 0xF 
hex_value_C = 0x98BADCFE & 0xF  
hex_value_D = 0x10325476 & 0xF   

# Convertimos el valor hexadecimal a binario y rellenamos con ceros a la izquierda para tener 32 bits
binary_value_A = bin(hex_value_A)[2:].zfill(numero_bits)  
binary_value_B = bin(hex_value_B)[2:].zfill(numero_bits)  
binary_value_C = bin(hex_value_C)[2:].zfill(numero_bits)  
binary_value_D = bin(hex_value_D)[2:].zfill(numero_bits) 

"""Constante k."""
K = [
        0xd76aa478, 0xe8c7b756, 0x242070db, 0xc1bdceee,
        0xf57c0faf, 0x4787c62a, 0xa8304613, 0xfd469501,
        0x698098d8, 0x8b44f7af, 0xffff5bb1, 0x895cd7be,
        0x6b901122, 0xfd987193, 0xa679438e, 0x49b40821,
        0xf61e2562, 0xc040b340, 0x265e5a51, 0xe9b6c7aa,
        0xd62f105d, 0x02441453, 0xd8a1e681, 0xe7d3fbc8,
        0x21e1cde6, 0xc33707d6, 0xf4d50d87, 0x455a14ed,
        0xa9e3e905, 0xfcefa3f8, 0x676f02d9, 0x8d2a4c8a,
        0xfffa3942, 0x8771f681, 0x6d9d6122, 0xfde5380c,
        0xa4beea44, 0x4bdecfa9, 0xf6bb4b60, 0xbebfbc70,
        0x289b7ec6, 0xeaa127fa, 0xd4ef3085, 0x04881d05,
        0xd9d4d039, 0xe6db99e5, 0x1fa27cf8, 0xc4ac5665,
        0xf4292244, 0x432aff97, 0xab9423a7, 0xfc93a039,
        0x655b59c3, 0x8f0ccc92, 0xffeff47d, 0x85845dd1,
        0x6fa87e4f, 0xfe2ce6e0, 0xa3014314, 0x4e0811a1,
        0xf7537e82, 0xbd3af235, 0x2ad7d2bb, 0xeb86d391
    ] 
"""Constante s."""
S = [
    7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,  7, 12, 17, 22,
    5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,  5,  9, 14, 20,
    4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,  4, 11, 16, 23,
    6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21,  6, 10, 15, 21
]
"""
    Realiza una operación XOR entre un conjunto de qubits de control y un conjunto correspondiente de qubits objetivo.
   
    """

def Xor( qc, control, target):

    for i in range(num_qubits):
        qc.cx(control[i], target[i])

def Not(qc, x):
        for j in range(len(x)):
            qc.x(x[j])

def And(qc, x, y, z):

    for j in range(len(x)):
        qc.ccx(x[j], y[j], z[j])

def Choice( qc, control, eleccion1, eleccion2):
    """
    /// # Resumen
    /// Aplica la operación de elección bit a bit en su lugar a tres registros de qubits. Si el
    /// control es 1, se selecciona la primera opción; si es 0, se selecciona la segunda opción.
    /// 
    /// # Entrada
    /// ## control
    /// Registro de control. No se modifica por la operación.
    /// 
    /// ## choice1
    /// Registro que contiene la primera opción. No se modifica por la operación.
    /// 
    /// ## choice2
    /// Registro que contiene la segunda opción. Para cada qubit en `control` que sea
    /// un 1, el qubit correspondiente se cambiará a ese en `choice1`o.
    """

    for i in range(len(eleccion1)):
        # Xor
        qc.cx(eleccion2[i], eleccion1[i])
        
        # And
        qc.ccx(control[i], eleccion1[i], eleccion2[i])
        
        # Xor
        qc.cx(eleccion2[i], eleccion1[i])
        
def left_rotation(qc, qubits, aux, amount):
    
    num_qubits = len(qubits)
    amount = amount % 4
    
    for j in range(amount):
        
        for i in range(num_qubits):
            qc.swap(qubits[i], aux[i])

        for i in range(num_qubits):
            if i == 0:
                qc.swap(qubits[i+3], aux[i])
            else: 
                qc.swap(qubits[i-1], aux[i])

def Cambio_L_B(qc, qr):
    for i in range(numero_bits // 2):
                qc.swap(qr[i], qr[numero_bits - i - 1])
    
def Indice_chunk(i):
    """
    Devuelve el índice de palabra apropiado en el fragmento actual
    basado en el valor del iterador. Esto es el `g` en el algoritmo MD5.
    
    Argumentos:
    i -- Valor del iterador.
    
    Retorna:
    Valor `g` correspondiente.
    """
    if i < 16:
        return i
    elif i < 32:
        return (5*i + 1) % 16
    elif i < 48:
        return (3*i + 5) % 16
    else:
        return (7*i) % 16

def Inicializacion_variables(qr_A, qr_B, qr_C, qr_D, qc):
# Inicialización de las variables A, B, C y D con qubits 

    # Cargar el número en el registro de qubits en formato little-endian
    for i in range(numero_bits):
        if binary_value_A[i] == '1':
            qc.x(qr_A[i])
        if binary_value_B[i] == '1':
            qc.x(qr_B[i])
        if binary_value_C[i] == '1':
            qc.x(qr_C[i])
        if binary_value_D[i] == '1':
            qc.x(qr_D[i])

def ComputeRound(a, b, c, d, qc, qr_target, words, qTemp_k, i, qcarry):
# Calculamos a contiene F + A + K[i] + M[g]
    if i == 0:
        # a += Choice(b, c, d)
        Choice(qc, b, c, d)

        Cambio_L_B(qc, a)
        Cambio_L_B(qc, d)

        qc.append(adder, d[:] + a[:] + [qcarry[0]])

        Cambio_L_B(qc, a)
        Cambio_L_B(qc, d)
        qc.mcx(a[:] + b[:] + c[:] + d[:], qr_target)

        Choice(qc, b, c, d) 

    elif i == 1:
        # a += Choice(d, b, c)
        Choice(qc, d, b, c)

        Cambio_L_B(qc, a)
        Cambio_L_B(qc, c)
        qc.append(adder, c[:] + a[:] + [qcarry[0]])
        Cambio_L_B(qc, a)
        Cambio_L_B(qc, c)
        qc.mcx(a[:] + b[:] + c[:] + d[:], qr_target)

        Choice(qc, d, b, c)

    elif i == 2:
        # a += b xor c xor d
        Xor(qc, b, d)
        Xor(qc, c, d)
        Cambio_L_B(qc, a)
        Cambio_L_B(qc, d)
        qc.append(adder, d[:] + a[:] + [qcarry[0]])
        Cambio_L_B(qc, a)
        Cambio_L_B(qc, d)
        qc.mcx(a[:] + b[:] + c[:] + d[:], qr_target)
        Xor(qc, b, d)
        Xor(qc, c, d)

    else:
        # a += (not c) xor ((not b) and d)
        Not(qc, b)
        Not(qc, c)
        And(qc, b, d, c)

        Cambio_L_B(qc, a)
        Cambio_L_B(qc, c)
        qc.append(adder, c[:] + a[:] + [qcarry[0]])
        Cambio_L_B(qc, a)
        Cambio_L_B(qc, c)

        qc.mcx(a[:] + b[:] + c[:] + d[:], qr_target)
        And(qc, b, d, c)
        Not(qc, b)
        Not(qc, c)
    
    Cambio_L_B(qc, words)
    Cambio_L_B(qc, a)
    qc.append(adder, words[:] + a[:] + [qcarry[0]])
    Cambio_L_B(qc, words)

    Cambio_L_B(qc, qTemp_k)
    qc.append(adder, qTemp_k[:] + a[:] + [qcarry[0]])
    Cambio_L_B(qc, qTemp_k)
    Cambio_L_B(qc, a)

def  Md5_qiskit(mensaje, qc, qr_A, qr_B, qr_C, qr_D, qTemp_k, qW, qcarry, qdestino): 

    # Pre-procesamiento del mensaje
    # Padding
    #mensaje_len = len(mensaje)
    
    # Asegurar que el mensaje tenga al menos 4 bytes (32 bits)
    #if mensaje_len < 4:
        #raise ValueError("El mensaje debe tener al menos 4 bytes para calcular el MD5.")
    
    # Calcular el número de ceros que se deben agregar para que la longitud del mensaje sea múltiplo de 4 bytes
    #padding_len = (mensaje_len % 4)
    
    # Agregar ceros al final del mensaje
    #mensaje += b'\x00' * padding_len
    

    # Procesamiento por bloques de 32 bits (4 bytes)
    for i in range(0, 1, numero_bits):

        # Operaciones principales
        for j in range(1):
            
            # Inicialización de K
            k_ayuda = K[1] & 0xf
            binary_value_K = bin(k_ayuda)[2:].zfill(numero_bits)

            for w in range(numero_bits):
                if binary_value_K[w] == '1':
                    qc.x(qTemp_k[w])
            #g =  Indice_chunk(i)
        
            #calculamos a contiene F + A + K[i] + M[g]
            ComputeRound(qr_A, qr_B, qr_C, qr_D, qc, qdestino, qW, qTemp_k, j, qcarry)
            
            #ponemos a 0 la variable temporal para utilizarla como auxiliar para la rotación a la izauierda
            for w in range(numero_bits):
                if binary_value_K[w] == '1':
                    qc.x(qTemp_k[w])
                
            #Aplicamos rotación a la izquierda y le sumamos b
            left_rotation(qc, qr_A, qTemp_k, S[j])

            Cambio_L_B(qc, qr_A)
            Cambio_L_B(qc, qr_B)
            qc.append(adder, qr_B[:] + qr_A[:] + [qcarry[0]])
            Cambio_L_B(qc, qr_A)
            Cambio_L_B(qc, qr_B)

                    
            # Copiar B en A 
            for i in range(numero_bits):
                qc.swap(qr_A[i], qr_D[i])

            # Copiar A en D 
            for i in range(numero_bits):
                qc.swap(qr_D[i], qr_C[i])

            # Copiar D en C y B en C 
            for i in range(numero_bits):
                qc.swap(qr_C[i], qr_B[i])
        
        # Aplicamos de nuevo una XOR al qbit temporal
        for w in range(numero_bits):
            if binary_value_K[w] == '1':
                qc.x(qTemp_k[w])

        Cambio_L_B(qc, qr_A)
        Cambio_L_B(qc, qr_B)
        Cambio_L_B(qc, qr_C)
        Cambio_L_B(qc, qr_D)

        for i in range(numero_bits):
            if binary_value_A[i] == '1':
                qc.x(qTemp_k[i])
        
        Cambio_L_B(qc, qTemp_k)
        qc.append(adder, qTemp_k[:] + qr_A[:] + [qcarry[0]])
        Cambio_L_B(qc, qTemp_k)

        for i in range(numero_bits):
            if binary_value_A[i] == '1':
                qc.x(qTemp_k[i])


        for i in range(numero_bits):
            if binary_value_B[i] == '1':
                qc.x(qTemp_k[i])
        
        Cambio_L_B(qc, qTemp_k)
        qc.append(adder, qTemp_k[:] + qr_B[:] + [qcarry[0]])
        Cambio_L_B(qc, qTemp_k)

        for i in range(numero_bits):
            if binary_value_B[i] == '1':
                qc.x(qTemp_k[i])
        

        for i in range(numero_bits):
            if binary_value_C[i] == '1':
                qc.x(qTemp_k[i])
        
        Cambio_L_B(qc, qTemp_k)
        qc.append(adder, qTemp_k[:] + qr_C[:] + [qcarry[0]])
        Cambio_L_B(qc, qTemp_k)

        for i in range(numero_bits):
            if binary_value_C[i] == '1':
                qc.x(qTemp_k[i])

        
        for i in range(numero_bits):
            if binary_value_D[i] == '1':
                qc.x(qTemp_k[i])
        
        Cambio_L_B(qc, qTemp_k)
        qc.append(adder, qTemp_k[:] + qr_D[:] + [qcarry[0]])
        Cambio_L_B(qc, qTemp_k)

        for i in range(numero_bits):
            if binary_value_D[i] == '1':
                qc.x(qTemp_k[i])


        Cambio_L_B(qc, qr_A)
        Cambio_L_B(qc, qr_B)
        Cambio_L_B(qc, qr_C)
        Cambio_L_B(qc, qr_D)
        
    
    return (qc)
    #1085 segundos


"""mensaje = b"Hola"
qc = Md5_qiskit(mensaje)
ideal_distribution = Statevector.from_instruction(qc).probabilities_dict()

for i in ideal_distribution:
    
    if ideal_distribution[i] > 0.5:
        print(i)"""
