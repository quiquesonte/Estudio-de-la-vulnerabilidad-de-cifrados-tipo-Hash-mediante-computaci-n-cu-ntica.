from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, Aer, transpile, assemble, execute
from qiskit.quantum_info import Statevector
from qiskit.visualization import plot_histogram
from qiskit.circuit.library import DraperQFTAdder
from qiskit.providers.aer.library import save_statevector
from qiskit.circuit import ControlledGate
from MD5_quantum_para_grover import Md5_qiskit, Inicializacion_variables, K
from MD5_simplificado_numeros_del_0_al_15 import md5
from qiskit import QuantumCircuit, execute
from qiskit.providers.aer import QasmSimulator 
import qiskit.quantum_info as qi
import numpy as np
# Función para aplicar Z controlada por todos los qubits en estado 0
def controlled_Z_all_zero(qc, target, controls):
    # Aplicar X a los qubits de control para invertir su estado
    for qubit in controls:
        qc.x(qubit)
    # Aplicar la compuerta Z controlada por todos los qubits de control (utilizando H, T, Tdg y X gates)
    qc.h(target)
    qc.mcx(controls, target)
    qc.h(target)
    # Restaurar el estado original de los qubits de control
    for qubit in controls:
        qc.x(qubit)

# Mensaje a cifrar 22cc para 0000
mensaje = 0b0000

# Calcular el MD5 del mensaje
numero_hex = md5(mensaje)

# Convertir a binario
mensaje_cod = ''.join(f'{int(digit, 16):04b}' for digit in numero_hex)
mensaje_lit = mensaje_cod[::-1]

# Definición de qr_A, qr_B, qr_C, qr_D, qTemp_k y qW
numero_bits = 4
qr_A = QuantumRegister(numero_bits, 'qr_A')
qr_B = QuantumRegister(numero_bits, 'qr_B')
qr_C = QuantumRegister(numero_bits, 'qr_C')
qr_D = QuantumRegister(numero_bits, 'qr_D')
qTemp_k = QuantumRegister(numero_bits, 'qTemp')
qW = QuantumRegister(numero_bits, 'qW')

# Nuevo registro cuántico para el carry
qcarry = QuantumRegister(1, 'qCarry')

# Nuevo registro cuántico para el destino
qdestino = QuantumRegister(1, 'qdestino')

# Declaro bits medida
cr = ClassicalRegister(5,'cr')

# Crear un circuito original
qc = QuantumCircuit(qr_A, qr_B, qr_C, qr_D, qTemp_k, qW, qcarry, qdestino, cr)

# Inicialización de variables
Inicializacion_variables(qr_A, qr_B, qr_C, qr_D, qc)

# Aplicar H gate a cada qubit en los registros de entrada
for qr in [qW]:
    qc.h(qr)

# Aplicar la compuerta X al qubit de destino
qc.x(qdestino)

#(PI/4)*sqrt((2^N)/K)
#Asumir n es el número de bits de entrada
#N=2^n y k es el número de combinaciones de entrada o objetivos de búsqueda "correctos".

num_qubits = 4

# Número de iteraciones de Grover
num_iterations = int(np.floor(np.pi/4 * np.sqrt(2**num_qubits)))


    
for _ in range(num_iterations):

    # Aplicar el oráculo MD5
    qc = Md5_qiskit(mensaje_lit, qc, qr_A, qr_B, qr_C, qr_D, qTemp_k, qW, qcarry, qdestino)

    # Guardar una copia del circuito actual antes de aplicar la puerta Z
    qc_before_Z = qc.copy()

    for a in range(16):
        if a < 4:
            if (mensaje_lit[a]) == '0':
                qc.x(qr_A[a])
        elif 4 <= a < 8:
            if (mensaje_lit[a]) == '0':
                qc.x(qr_B[a-4])
        elif 8 <= a < 12:
            if (mensaje_lit[a]) == '0':
                qc.x(qr_C[a-8])
        elif 12 <= a < 16:
            if (mensaje_lit[a]) == '0':
                qc.x(qr_D[a-12])  

    qc.h(qdestino[0])
    qc.mcx(list(qr_A) + list(qr_B) + list(qr_C) + list(qr_D), qdestino[0])        
    qc.h(qdestino[0])
        
    for i in range(16):
        if i < 4:
            if (mensaje_lit[i]) == '0':
                qc.x(qr_D[i])
        elif 4 <= i < 8:
            if (mensaje_lit[i]) == '0':
                qc.x(qr_C[i-4])
        elif 8 <= i < 12:
            if (mensaje_lit[i]) == '0':
                qc.x(qr_B[i-8])
        elif 12 <= i < 16:
            if (mensaje_lit[i]) == '0':
                qc.x(qr_A[i-12])  
    
    # Obtener el circuito inverso de qc_before_Z
    qc_inverse = qc_before_Z.inverse()

    # Agregar el circuito inverso después de aplicar la puerta Z
    qc = qc.compose(qc_inverse)
    
    # Imprimir los resultados, len va a ser 2 elevado al número de qubits utilizados (26)
    #stv1 = qi.Statevector.from_instruction(qc)

    #sim = QasmSimulator()
    #options = {'method': 'statevector'}
    #execute(qc, sim, backend_options=options)

    #print(stv1[0b10000000000010111000111110])
    
    # Aplicar H gate a cada qubit en los registros de entrada
    for qr in [qW]:
        qc.h(qr)

    #qc.h(qr_target)
    # Aplicar Z controlada por todos los qubits de entrada al qubit de destino
    controlled_Z_all_zero(qc, qdestino, qW[:])
    #qc.h(qr_target)

    # Aplicar H gate a cada qubit en los registros de entrada
    for qr in [qW]:
        qc.h(qr)


gate_counts = qc.count_ops()
total_gates = sum(gate_counts.values())
print(f"Total number of gates: {total_gates}")
circuit_depth = qc.depth()
circuit_size = qc.size()
num_qubits = qc.num_qubits
print(f"Number of qubits: {num_qubits}")
print(f"Depth of circuit: {circuit_depth}")
print(f"Size of circuit (number of operations): {circuit_size}")




