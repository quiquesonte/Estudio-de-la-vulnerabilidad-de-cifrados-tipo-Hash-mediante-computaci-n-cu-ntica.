from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, Aer, transpile, assemble, execute
from qiskit.providers.aer import QasmSimulator
import qiskit.quantum_info as qi

# Número de qubits de entrada
n = 4

# Crear registros cuánticos y clásicos
qreg = QuantumRegister(n, 'q')
target_qubit = QuantumRegister(1, 't')
creg = ClassicalRegister(n + 1, 'c')

# Crear circuito cuántico
circuit = QuantumCircuit(qreg, target_qubit, creg)

# Aplicar puertas Hadamard a cada qubit de entrada
circuit.h(qreg)

# Aplicar la puerta X al qubit de destino
circuit.x(target_qubit)

# Aplicar puerta Z controlada si los qubits están en el estado 1000
# Invertir qreg[1], qreg[2] y qreg[3] para que sean 0 si son 1 (y viceversa)
circuit.x(qreg[1])
circuit.x(qreg[2])
circuit.x(qreg[3])

# Aplicar una puerta Z controlada por los qubits qreg[0], qreg[1], qreg[2], qreg[3]
circuit.h(target_qubit[0])
circuit.mcx(qreg[:n], target_qubit[0])
circuit.h(target_qubit[0])

# Revertir los qubits de control al estado original
circuit.x(qreg[1])
circuit.x(qreg[2])
circuit.x(qreg[3])

# Mostrar el circuito
print(circuit.draw())

# Obtener el vector de estado del circuito
stv1 = qi.Statevector.from_instruction(circuit)
print("\nVector de estado final:")

# Imprimir cada elemento del vector de estado
for i, amplitude in enumerate(stv1.data):
    print(f"State {i:0{n+1}b}: {amplitude}")
